import { useState, useEffect, useMemo, useRef, useCallback } from "react";

// ── Verified 2025 final HR leaders ───────────────────────────────────────────
const SEED_2025 = [
  { name: "Cal Raleigh",     team: "SEA", hr2025: 60, careerGPHR: 6.2  },
  { name: "Kyle Schwarber",  team: "PHI", hr2025: 56, careerGPHR: 5.6  },
  { name: "Shohei Ohtani",   team: "LAD", hr2025: 55, careerGPHR: 4.3  },
  { name: "Aaron Judge",     team: "NYY", hr2025: 53, careerGPHR: 3.2  },
  { name: "Eugenio Suarez",  team: "SEA", hr2025: 49, careerGPHR: 7.0  },
  { name: "Junior Caminero", team: "TB",  hr2025: 45, careerGPHR: 5.5  },
  { name: "Juan Soto",       team: "NYM", hr2025: 43, careerGPHR: 6.8  },
  { name: "Pete Alonso",     team: "NYM", hr2025: 38, careerGPHR: 5.8  },
  { name: "Jo Adell",        team: "LAA", hr2025: 37, careerGPHR: 9.5  },
  { name: "Taylor Ward",     team: "LAA", hr2025: 36, careerGPHR: 10.2 },
  { name: "Riley Greene",    team: "DET", hr2025: 36, careerGPHR: 8.8  },
  { name: "Nick Kurtz",      team: "OAK", hr2025: 36, careerGPHR: 7.0  },
  { name: "Rafael Devers",   team: "BOS", hr2025: 35, careerGPHR: 6.3  },
  { name: "Byron Buxton",    team: "MIN", hr2025: 35, careerGPHR: 6.5  },
  { name: "Trent Grisham",   team: "NYY", hr2025: 34, careerGPHR: 11.5 },
];

// ── Color: pink=fresh, lime=eruption ─────────────────────────────────────────
function ratioToStyle(ratio) {
  if (ratio == null) return { color: "#3f3f52", label: "—", glow: false };
  const r = Math.min(3.5, Math.max(0, ratio));
  const stops = [
    { at: 0.0, rgb: [155, 55,  95] },
    { at: 0.5, rgb: [130, 55,  85] },
    { at: 0.8, rgb: [175, 120, 30] },
    { at: 1.0, rgb: [190, 185, 30] },
    { at: 1.5, rgb: [ 75, 195, 50] },
    { at: 2.0, rgb: [ 25, 210, 70] },
    { at: 3.0, rgb: [  5, 240, 95] },
  ];
  let lo = stops[0], hi = stops[stops.length - 1];
  for (let i = 0; i < stops.length - 1; i++) {
    if (r >= stops[i].at && r <= stops[i + 1].at) { lo = stops[i]; hi = stops[i + 1]; break; }
  }
  const t = lo.at === hi.at ? 0 : (r - lo.at) / (hi.at - lo.at);
  const lerp = (a, b) => Math.round(a + (b - a) * t);
  const color = `rgb(${[0,1,2].map(j => lerp(lo.rgb[j], hi.rgb[j])).join(",")})`;
  let label = "FRESH";
  if      (r >= 2.5)  label = "ERUPTION";
  else if (r >= 1.75) label = "OVERDUE";
  else if (r >= 1.1)  label = "DUE";
  else if (r >= 0.75) label = "AVERAGE";
  else if (r >= 0.3)  label = "RECENT";
  return { color, label, glow: r >= 1.75 };
}

// ── Fuzzy name match ──────────────────────────────────────────────────────────
function norm(s) {
  return (s ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .toLowerCase().replace(/[^a-z ]/g, "").trim();
}
function fuzzyFind(arr, name) {
  const sn = norm(name);
  const parts = sn.split(" ");
  const last = parts[parts.length - 1];
  return arr.find(r => norm(r.name) === sn)
    || arr.find(r => { const rn = norm(r.name); return rn.includes(last) && rn[0] === parts[0][0]; })
    || arr.find(r => norm(r.name).includes(last))
    || null;
}

// ── Fetch pre-built JSON from GitHub ─────────────────────────────────────────
// YOUR_GITHUB_USERNAME and YOUR_REPO_NAME get filled in during setup
// e.g. "https://raw.githubusercontent.com/mikeyduran/droughtwatch/main/data/drought.json"
const DATA_URL = "https://raw.githubusercontent.com/YOUR_GITHUB_USERNAME/droughtwatch/main/data/drought.json";

async function fetchDroughtData() {
  const res = await fetch(DATA_URL);
  if (!res.ok) throw new Error(`GitHub fetch failed: ${res.status}`);
  return res.json();
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [rows,        setRows]        = useState([]);
  const [phase,       setPhase]       = useState("idle");
  const [loadMsg,     setLoadMsg]     = useState("");
  const [progress,    setProgress]    = useState(0);
  const [errMsg,      setErrMsg]      = useState("");
  const [search,      setSearch]      = useState("");
  const [labelFilter, setLabelFilter] = useState("ALL");
  const [sortKey,     setSortKey]     = useState("ratio");
  const [sortDir,     setSortDir]     = useState("desc");
  const [tab,         setTab]         = useState("all");
  const dead = useRef(false);

  const runLoad = useCallback(async () => {
    dead.current = false;
    setPhase("loading");
    setErrMsg("");
    setLoadMsg("Loading from GitHub…");
    setProgress(0);

    try {
      const data = await fetchDroughtData();

      if (!data.players?.length) {
        throw new Error("No player data yet — go to your GitHub repo and run the workflow manually.");
      }

      const built = data.players.map((p, i) => {
        const ratio = p.ratio ?? (p.drought != null && p.careerGPHR
          ? +(p.drought / p.careerGPHR).toFixed(3) : null);
        const { color, label, glow } = ratioToStyle(ratio);
        const seed = SEED_2025.find(s => s.name === p.name);
        return {
          id: `p${i}`, source: p.hr2025 ? "both" : "2026",
          name: p.name, team: p.team,
          hr2025:     p.hr2025 ?? seed?.hr2025 ?? null,
          hr2026:     p.hr2026,  gp2026: p.gp2026,
          drought:    p.drought, lastHR: p.lastHR,
          careerGPHR: p.careerGPHR ?? seed?.careerGPHR ?? null,
          seasonGPHR: p.seasonGPHR,
          ratio, color, label, glow,
        };
      });

      setRows(built);
      setProgress(100);
      setPhase("done");
      setLoadMsg(data.updatedLabel ? `Updated: ${data.updatedLabel}` : "");

    } catch (e) {
      setErrMsg(e.message);
      setPhase("error");
      setLoadMsg("");
    }
  }, []);

  useEffect(() => {
    runLoad();
    return () => { dead.current = true; };
  }, []); // eslint-disable-line

  const tabRows = useMemo(() => {
    if (tab === "2025") return rows.filter(r => r.source === "2025" || r.source === "both");
    if (tab === "2026") return rows.filter(r => r.source === "2026" || r.source === "both");
    return rows;
  }, [rows, tab]);

  const labelCounts = useMemo(() => {
    const c = { ALL: 0 };
    LABEL_ORDER.forEach(l => { c[l] = 0; });
    tabRows.forEach(r => {
      c.ALL++;
      if (r.label && !["LOADING","—"].includes(r.label)) c[r.label] = (c[r.label] ?? 0) + 1;
    });
    return c;
  }, [tabRows]);

  const displayed = useMemo(() => {
    let list = [...tabRows];
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(r => r.name?.toLowerCase().includes(q) || r.team?.toLowerCase().includes(q));
    }
    if (labelFilter !== "ALL") list = list.filter(r => r.label === labelFilter);
    const nv = sortDir === "desc" ? -Infinity : Infinity;
    list.sort((a, b) => {
      const av = a[sortKey] ?? nv, bv = b[sortKey] ?? nv;
      return av === bv ? 0 : sortDir === "desc" ? bv - av : av - bv;
    });
    return list;
  }, [tabRows, search, labelFilter, sortKey, sortDir]);

  function toggleSort(k) {
    if (k === sortKey) setSortDir(d => d === "desc" ? "asc" : "desc");
    else { setSortKey(k); setSortDir("desc"); }
  }

  return (
    <div style={{ minHeight:"100vh", background:"#0d0d14", color:"#c8c8d0", fontFamily:"'Outfit',system-ui,sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap');
        *{box-sizing:border-box;margin:0;padding:0}
        @keyframes shimmer{0%{background-position:-400px 0}100%{background-position:400px 0}}
        @keyframes fadeUp{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}
        @keyframes spin{to{transform:rotate(360deg)}}
        .trow:hover td{background:rgba(255,255,255,.022)!important}
        ::-webkit-scrollbar{width:5px;height:5px}
        ::-webkit-scrollbar-track{background:#0d0d14}
        ::-webkit-scrollbar-thumb{background:#252535;border-radius:3px}
        input,button{font-family:inherit}
        .sth:hover{color:#a1a1b0!important}
        .chip:hover{opacity:.82}
      `}</style>

      {/* HEADER */}
      <div style={{ background:"#07070e", borderBottom:"1px solid #161624", padding:"22px 24px 18px" }}>
        <div style={{ maxWidth:1100, margin:"0 auto" }}>
          <div style={{ display:"flex", alignItems:"flex-end", justifyContent:"space-between", gap:12, flexWrap:"wrap", marginBottom:14 }}>
            <div>
              <h1 style={{ fontSize:"clamp(26px,4vw,44px)", fontWeight:900, letterSpacing:-1, color:"#fff", lineHeight:1 }}>
                ⚾ Drought<span style={{ color:"#05f064" }}>Watch</span>
              </h1>
              <p style={{ marginTop:5, fontSize:12, color:"#52525b", lineHeight:1.6 }}>
                Top 15 of 2025 + top 15 of 2026 · drought pressure vs each player's career rate ·{" "}
                <span style={{ color:"#804058" }}>pink</span> = just hit one · <span style={{ color:"#05f064" }}>green</span> = way overdue
              </p>
            </div>
            <div style={{ display:"flex", gap:8, alignItems:"center" }}>
              {phase === "loading" && (
                <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                  <div style={{ width:16, height:16, borderRadius:"50%", border:"2px solid #1e1e2c", borderTop:"2px solid #05f064", animation:"spin 1s linear infinite" }} />
                  <span style={{ fontSize:11, color:"#52525b" }}>{loadMsg}</span>
                </div>
              )}
              {phase !== "loading" && (
                <button onClick={runLoad} style={{ background:"transparent", border:"1px solid #252535", borderRadius:8, padding:"7px 14px", color:"#52525b", fontSize:12, cursor:"pointer", transition:"all .2s" }}
                  onMouseEnter={e=>{e.currentTarget.style.borderColor="#05f064";e.currentTarget.style.color="#05f064";}}
                  onMouseLeave={e=>{e.currentTarget.style.borderColor="#252535";e.currentTarget.style.color="#52525b";}}>
                  ↺ {phase === "error" ? "Retry" : "Refresh"}
                </button>
              )}
            </div>
          </div>

          {phase === "loading" && (
            <div style={{ marginBottom:14, height:3, background:"#161624", borderRadius:2, overflow:"hidden" }}>
              <div style={{ height:"100%", width:`${progress}%`, background:"linear-gradient(90deg,#804058,#c8a820,#05f064)", borderRadius:2, transition:"width .5s ease" }} />
            </div>
          )}

          {/* Legend */}
          <div style={{ display:"flex", borderRadius:8, overflow:"hidden", border:"1px solid #161624" }}>
            {[{l:"FRESH",d:"Just hit one",c:"#804058"},{l:"RECENT",d:"Below avg",c:"#a05878"},{l:"AVERAGE",d:"At career avg",c:"#c8a820"},{l:"DUE",d:"Past avg",c:"#a8d840"},{l:"OVERDUE",d:"Well overdue",c:"#3dd068"},{l:"ERUPTION",d:"Way past avg",c:"#05f064"}]
              .map((s,i) => (
                <div key={s.l} style={{ flex:1, padding:"8px 4px", background:`${s.c}10`, borderLeft:i>0?"1px solid #161624":"none", textAlign:"center" }}>
                  <div style={{ height:3, background:s.c, borderRadius:1, marginBottom:5, boxShadow:i>=4?`0 0 7px ${s.c}`:"none" }} />
                  <div style={{ fontSize:9, fontWeight:700, color:s.c, letterSpacing:.5 }}>{s.l}</div>
                  <div style={{ fontSize:8, color:"#3f3f52", marginTop:1 }}>{s.d}</div>
                </div>
              ))}
          </div>
        </div>
      </div>

      {/* BODY */}
      <div style={{ maxWidth:1100, margin:"0 auto", padding:"16px 24px 60px" }}>

        {errMsg && (
          <div style={{ marginBottom:12, padding:"10px 16px", background:"rgba(239,68,68,.07)", border:"1px solid rgba(239,68,68,.2)", borderRadius:8, color:"#f87171", fontSize:12 }}>
            ⚠ {errMsg}
          </div>
        )}

        {/* Controls */}
        <div style={{ display:"flex", gap:8, marginBottom:12, flexWrap:"wrap", alignItems:"center" }}>
          <div style={{ display:"flex", border:"1px solid #1e1e2c", borderRadius:8, overflow:"hidden" }}>
            {[["all","All"],["2025","2025 List"],["2026","2026 List"]].map(([v,lbl]) => (
              <button key={v} onClick={()=>setTab(v)} style={{ padding:"7px 13px", fontSize:11, fontWeight:500, background:tab===v?"#1e1e2c":"transparent", color:tab===v?"#e0e0ea":"#52525b", border:"none", cursor:"pointer", transition:"all .15s", borderRight:v!=="2026"?"1px solid #1e1e2c":"none" }}>{lbl}</button>
            ))}
          </div>
          <div style={{ position:"relative", flex:1, minWidth:160, maxWidth:280 }}>
            <span style={{ position:"absolute", left:10, top:"50%", transform:"translateY(-50%)", fontSize:12, color:"#3f3f52", pointerEvents:"none" }}>🔍</span>
            <input type="text" placeholder="Search player or team…" value={search} onChange={e=>setSearch(e.target.value)}
              style={{ width:"100%", background:"#111118", border:"1px solid #1e1e2c", borderRadius:8, padding:"7px 12px 7px 30px", color:"#d0d0d8", fontSize:12, outline:"none" }}
              onFocus={e=>e.target.style.borderColor="#2e2e4e"} onBlur={e=>e.target.style.borderColor="#1e1e2c"} />
          </div>
          <span style={{ marginLeft:"auto", fontSize:11, color:"#3f3f52" }}>{displayed.length} players</span>
        </div>

        {/* Chips */}
        <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginBottom:14 }}>
          {LABEL_ORDER.map(lbl => {
            const col = LABEL_COLORS[lbl] ?? "#71717a";
            const active = labelFilter === lbl;
            return (
              <button key={lbl} className="chip" onClick={()=>setLabelFilter(lbl)} style={{ background:active?`${col}20`:"transparent", border:`1px solid ${active?col:"#1e1e2c"}`, borderRadius:6, padding:"4px 11px", color:active?col:"#52525b", fontSize:11, fontWeight:active?600:400, transition:"all .14s", display:"flex", alignItems:"center", gap:5 }}>
                {lbl!=="ALL"&&<span style={{ width:5,height:5,borderRadius:"50%",background:col,flexShrink:0 }}/>}
                {lbl} <span style={{ opacity:.45,fontSize:10 }}>{labelCounts[lbl]??0}</span>
              </button>
            );
          })}
        </div>

        {/* Table */}
        <div style={{ background:"#09090f", border:"1px solid #161624", borderRadius:10, overflow:"hidden" }}>
          <div style={{ overflowX:"auto" }}>
            <table style={{ width:"100%", borderCollapse:"collapse", fontSize:13 }}>
              <thead>
                <tr style={{ background:"#060610", borderBottom:"1px solid #161624" }}>
                  {[
                    {l:"#",k:null,a:"center",w:36},
                    {l:"PLAYER",k:null,a:"left"},
                    {l:"PRESSURE",k:"ratio",a:"right"},
                    {l:"GAUGE",k:null,a:"center",w:100},
                    {l:"DROUGHT",k:"drought",a:"right"},
                    {l:"CAREER GP/HR",k:"careerGPHR",a:"right"},
                    {l:"2026 HR",k:"hr2026",a:"right"},
                    {l:"2026 GP",k:"gp2026",a:"right"},
                    {l:"2025 HR",k:"hr2025",a:"right"},
                  ].map(col => (
                    <th key={col.l} onClick={()=>col.k&&toggleSort(col.k)} className={col.k?"sth":""}
                      style={{ padding:"9px 14px", textAlign:col.a, width:col.w, fontSize:9, letterSpacing:2, fontWeight:500, color:sortKey===col.k?"#c8c8d8":"#3f3f52", cursor:col.k?"pointer":"default", userSelect:"none", whiteSpace:"nowrap", borderBottom:"1px solid #161624", transition:"color .15s" }}>
                      {col.l}{sortKey===col.k?(sortDir==="desc"?" ↓":" ↑"):""}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {displayed.map((p, i) => {
                  const loaded = !["LOADING"].includes(p.label);
                  const hasRatio = p.ratio != null;
                  const col = p.color ?? "#3f3f52";

                  return (
                    <tr key={p.id} className="trow" style={{ borderBottom:"1px solid #101018", transition:"background .1s", animation:`fadeUp .18s ease ${Math.min(i*.01,.16)}s both` }}>

                      <td style={{ padding:"11px 14px", textAlign:"center", color:"#252535", fontSize:10 }}>{i+1}</td>

                      {/* Player */}
                      <td style={{ padding:"10px 14px" }}>
                        <div style={{ display:"flex", alignItems:"center", gap:8, flexWrap:"wrap" }}>
                          <span style={{ fontWeight:700, color:"#e8e8f2", fontSize:14, whiteSpace:"nowrap" }}>{p.name}</span>
                          <span style={{ fontSize:10, color:"#52525b", fontWeight:500, letterSpacing:1 }}>{p.team}</span>
                          {loaded
                            ? p.hr2026 != null && <span style={{ fontSize:11, fontWeight:700, padding:"1px 8px", borderRadius:5, color:"#a1a1b0", background:"rgba(161,161,176,0.1)", border:"1px solid rgba(161,161,176,0.2)", whiteSpace:"nowrap" }}>{p.hr2026} HR</span>
                            : <Skel w={38} h={16}/>}
                          {loaded && p.lastHR &&
                            <span style={{ fontSize:10, color:"#52525b", whiteSpace:"nowrap" }}>last: <span style={{ color:"#71717a" }}>{p.lastHR}</span></span>}
                          {!loaded && <Skel w={60} h={10}/>}
                        </div>
                      </td>

                      {/* Pressure */}
                      <td style={{ padding:"10px 14px", textAlign:"right" }}>
                        {loaded && hasRatio
                          ? <div style={{ display:"flex", flexDirection:"column", alignItems:"flex-end", gap:1 }}>
                              <span style={{ fontSize:20, fontWeight:800, lineHeight:1, color:col, textShadow:p.glow?`0 0 16px ${col}`:"none" }}>{p.ratio.toFixed(2)}×</span>
                              <span style={{ fontSize:8, fontWeight:700, color:col, opacity:.75, letterSpacing:1 }}>{p.label}</span>
                            </div>
                          : loaded ? <span style={{ color:"#252535",fontSize:12 }}>—</span>
                          : <Skel w={52} h={22}/>}
                      </td>

                      {/* Gauge */}
                      <td style={{ padding:"10px 14px" }}>
                        {loaded ? <PressureBar ratio={p.ratio} color={col}/> : <Skel w={80} h={5}/>}
                      </td>

                      {/* Drought */}
                      <td style={{ padding:"10px 14px", textAlign:"right" }}>
                        {loaded
                          ? <span style={{ fontSize:16, fontWeight:700, color:hasRatio?col:"#3f3f52" }}>{p.drought!=null?`${p.drought}g`:"—"}</span>
                          : <Skel w={30} h={14}/>}
                      </td>

                      {/* Career GP/HR */}
                      <td style={{ padding:"10px 14px", textAlign:"right", color:"#71717a", fontSize:12 }}>
                        {p.careerGPHR!=null?p.careerGPHR.toFixed(1):"—"}
                      </td>

                      {/* 2026 HR */}
                      <td style={{ padding:"10px 14px", textAlign:"right", fontWeight:600, color:p.hr2026!=null?"#e0e0ea":"#252535" }}>
                        {loaded?(p.hr2026??"—"):<Skel w={24} h={11}/>}
                      </td>

                      {/* 2026 GP */}
                      <td style={{ padding:"10px 14px", textAlign:"right", color:"#52525b", fontSize:12 }}>
                        {loaded?(p.gp2026??"—"):<Skel w={24} h={11}/>}
                      </td>

                      {/* 2025 HR */}
                      <td style={{ padding:"10px 14px", textAlign:"right", color:p.hr2025!=null?"#71717a":"#252535", fontSize:12 }}>
                        {p.hr2025??"—"}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {displayed.length===0 && (
            <div style={{ padding:48, textAlign:"center", color:"#3f3f52", fontSize:13 }}>No players match your filters.</div>
          )}
        </div>

        <div style={{ marginTop:14, display:"flex", gap:24, flexWrap:"wrap", fontSize:10, color:"#1e1e2c" }}>
          <span>Pressure = drought ÷ career GP/HR · 1.0× = at personal avg · 2.0× = double overdue</span>
          <span style={{ marginLeft:"auto" }}>2025 verified · 2026 via Claude web search</span>
        </div>
      </div>
    </div>
  );
}

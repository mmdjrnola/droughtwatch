# ⚾ DroughtWatch

MLB Home Run Drought Tracker — measures each player's current drought relative to their own career HR rate.

## How it works

- A GitHub Action runs every morning at **8am ET** (before first pitch)
- It hits the free MLB Stats API, calculates drought + pressure scores for the top 50 HR hitters
- It commits `data/drought.json` to this repo
- The React app reads that file directly — **instant load, zero API calls at runtime**

---

## Setup (one time, ~10 minutes)

### 1. Fork or create this repo

Go to [github.com](https://github.com) → New repository → name it `droughtwatch` → set to **Public** (required for the free raw.githubusercontent.com URL).

Upload these files:
```
scrape.py
data/drought.json          ← the empty placeholder
.github/workflows/update.yml
```

### 2. Give the Action write permission

In your repo: **Settings → Actions → General → Workflow permissions**  
→ Select **"Read and write permissions"** → Save

### 3. Run it manually the first time

**Actions tab** → "Update Drought Data" → **Run workflow** → Run

Watch it complete (~2 min). It will commit a populated `data/drought.json`.

### 4. Update the app URL

In the React artifact, find this line near the top:

```js
const DATA_URL = "https://raw.githubusercontent.com/YOUR_GITHUB_USERNAME/droughtwatch/main/data/drought.json";
```

Replace `YOUR_GITHUB_USERNAME` with your actual GitHub username.

### 5. Done

The app now loads instantly from the pre-built JSON. The Action runs automatically every morning at 8am ET. You can also trigger it manually anytime from the Actions tab.

---

## Files

| File | Purpose |
|------|---------|
| `scrape.py` | Pulls MLB Stats API data, writes `data/drought.json` |
| `.github/workflows/update.yml` | Schedules the scraper daily at 8am ET |
| `data/drought.json` | Pre-built data file — read directly by the app |

## Pressure scale

| Label | Meaning |
|-------|---------|
| FRESH | Just hit one (0–30% of their avg gap) |
| RECENT | Below their average gap |
| AVERAGE | Right at their career average gap |
| DUE | Past their average — slightly overdue |
| OVERDUE | Well past their average |
| ERUPTION | Way past their average — due to go off |

Pressure = `current drought ÷ career GP/HR`.  
`1.0×` = exactly at their average. `2.0×` = double their average gap without a HR.
